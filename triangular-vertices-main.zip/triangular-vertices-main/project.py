# importing exit function from sys module
from sys import exit
#function to constructing triangular grid
def triangle_grid():
    number = int(input("Enter number of rows for triangular grid : "))
    value = 0
    for i in range(number):
        for j in range((number - i) - 1):
            space()
        for j in range(i + 1):
            value += 1
            print(format(value, "<4"), end=" ")
        print()

#function to get spaces
def space():
    print(end="  ")

# checking if it is triangle or not
def triangle(a):
    row_diff = abs(m[0][2] - m[1][2])
    vertex_diff1 = a[1] - a[0]
    vertex_diff2 = a[2] - a[1]
    vertex_diff3 = a[2] - a[0]
    if vertex_diff1 >= vertex_diff2:
        diff_min1 = abs(m[0][0] - a[0])
        diff_min2 = abs(m[1][0] - a[1])
        vertex_diff3 = vertex_diff2
    else:
        diff_min1 = abs(m[0][0] - a[0])
        diff_min2 = abs(m[1][0] - a[2])
        vertex_diff3 = vertex_diff1
    if vertex_diff3 == row_diff and (diff_min1 == diff_min2 or diff_min1 + row_diff == diff_min2):
        for i in h:
            print(i, sep=' ', end=' ')
        print("are the vertices of a triangle")
    else:
        not_accept(h)

# checking if it is parallelogram  or not
def parallelogram(a, m):
    row_diff = abs(m[0][2] - m[1][2])
    min_diff1 = abs(m[0][0] - a[0])
    min_diff2 = abs(m[1][0] - a[2])
    side1 = a[1] - a[0]
    side2 = a[3] - a[2]
    side3 = a[2] - a[0]
    side4 = a[3] - a[1]
    if side1 == side2 and side3 == side4 and side1 == row_diff and (min_diff1 == min_diff2 or min_diff1 + row_diff == min_diff2):
        for i in h:
            print(i, sep=' ', end=' ')
        print("are the vertices of a parallelogram")
    else:
        not_accept(h)

# checking if it is  hexagon or not
def hexagon(a, m):
    min_diff1 = abs(m[0][2] - m[1][2])
    min_diff2 = abs(m[1][2] - m[2][2])
    side1 = a[1] - a[0]
    side2 = a[5] - a[4]
    side3 = a[3] - a[2]
    if side1 == side2 and side3 == side2 + min_diff1 and side2 == min_diff2:
        for i in h:
           print(i, sep=' ', end=' ')
        print("are the vertices of a hexagon")
    else:
        not_accept(h)
        
#function if the vertex belongs to not acceptable vertices
def not_accept(a):
    for i in a:
        print(i, sep=' ', end=' ')
    print("are not the vertices of an acceptable figure")

# collecting data related  to input points given and manupulating them
def max_min_len(h):
    h.sort()
    start = 1;
    end = 1;
    k = 0;
    row_no = 0
    m = []
    while (True):
        while (True):
            if a[k] >= start and a[k] <= end:
                if row_no == 0:
                    p = [start, end, row_no + 1]
                else:
                    p = [start, end, row_no]
                if p not in m:
                    m.append(p)
                break
            if row_no == 0:
                start = start + row_no
                end = end + row_no
            else:
                start = start + row_no
                end = end + row_no + 1
            row_no = row_no + 1
        k = k + 1
        if len(a) == k:
            break
    return (m)

# drawing triangular grid
triangle_grid()

# taking inputs from user
while (True):
    h = list(map(int, input().split()))
    if (h == []):
        exit(0)
    a = []
    for i in h:
        a.append(i)

    # checking if it is an acceptable figure or not
    if len(a) == 3:
        m = max_min_len(a)
        if len(m) == 2:
            triangle(a)
        else:
            not_accept(h)
    elif len(a) == 4:
        m = max_min_len(a)
        if len(m) == 2:
            parallelogram(a, m)
        else:
            not_accept(h)
    elif len(a) == 6:
        m = max_min_len(a)
        if len(m) == 3:
            hexagon(a, m)
        else:
            not_accept(h)
    else:
        not_accept(h)
